<?php
    /*
    Plugin Name: Halk Ödeme Hizmetleri Sanal Pos
    Plugin URI: https://www.parao.com.tr/
    Description: Woocommerce için Halk Ödeme Entegrasyonu
    Domain Path: /i18n/languages/
    Text Domain: halkode
    Version: 2.9.3
    Requires at least: 7.0
    Requires PHP: 8.0
    Requires Plugins: woocommerce
    WC requires at least: 11.0

    */
    if (!defined('ABSPATH')) {
        exit;
    }



    
    add_action('before_woocommerce_init', function () {
        if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
            \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
        }
    });

    add_action('woocommerce_blocks_loaded', function () {
        if (!class_exists('\Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')) {
            return;
        }
        require_once __DIR__ . '/halkode-blocks.php';
        add_action('woocommerce_blocks_payment_method_type_registration', function ($payment_method_registry) {
            $payment_method_registry->register(new Halkode_Blocks_Payment_Method());
        });
    });

    add_action('plugins_loaded', 'halkode_pos', 20);
    add_action('init', 'my_custom_public_page');
    add_action('template_redirect', 'halkode_virtual_payment_result', 0);
    add_action('send_headers', 'halkode_send_security_headers');

    function halkode_is_local_host()
    {
        $host = isset($_SERVER['HTTP_HOST']) ? strtolower((string)$_SERVER['HTTP_HOST']) : '';
        $host = preg_replace('/:\d+$/', '', $host);
        return in_array($host, ['localhost', '127.0.0.1', '::1'], true);
    }

    function halkode_send_security_headers()
    {
        if (headers_sent()) {
            return;
        }

        if (is_ssl() && !halkode_is_local_host()) {
            header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
        }

        header('X-Content-Type-Options: nosniff');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
    }

    function halkode_is_allowed_remote_url($url)
    {
        $parts = wp_parse_url((string)$url);
        if (!is_array($parts)) {
            return false;
        }

        $scheme = strtolower((string)($parts['scheme'] ?? ''));
        $host = strtolower((string)($parts['host'] ?? ''));
        $path = (string)($parts['path'] ?? '');

        return $scheme === 'https'
            && in_array($host, ['staging.halkode.com.tr', 'app.halkode.com.tr'], true)
            && strpos($path, '/ccpayment/') === 0;
    }

    function halkode_handoff_key()
    {
        return hash('sha256', wp_salt('auth') . '|' . wp_salt('secure_auth'), true);
    }

    function halkode_encrypt_handoff(array $payload)
    {
        if (!function_exists('openssl_encrypt')) {
            return new WP_Error('halkode_crypto', __('Sunucuda OpenSSL etkin değil.', 'halkode'));
        }

        $json = wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($json === false) {
            return new WP_Error('halkode_crypto', __('Ödeme aktarım verisi oluşturulamadı.', 'halkode'));
        }

        try {
            $iv = random_bytes(12);
        } catch (Exception $e) {
            return new WP_Error('halkode_crypto', __('Güvenli rastgele veri üretilemedi.', 'halkode'));
        }

        $tag = '';
        $ciphertext = openssl_encrypt($json, 'aes-256-gcm', halkode_handoff_key(), OPENSSL_RAW_DATA, $iv, $tag, '', 16);
        if ($ciphertext === false) {
            return new WP_Error('halkode_crypto', __('Ödeme aktarım verisi şifrelenemedi.', 'halkode'));
        }

        return 'hk1:' . base64_encode($iv . $tag . $ciphertext);
    }

    function halkode_decrypt_handoff($encoded)
    {
        if (!is_string($encoded) || strpos($encoded, 'hk1:') !== 0 || !function_exists('openssl_decrypt')) {
            return new WP_Error('halkode_crypto', __('Geçersiz ödeme aktarım verisi.', 'halkode'));
        }

        $raw = base64_decode(substr($encoded, 4), true);
        if ($raw === false || strlen($raw) < 29) {
            return new WP_Error('halkode_crypto', __('Ödeme aktarım verisi bozuk.', 'halkode'));
        }

        $iv = substr($raw, 0, 12);
        $tag = substr($raw, 12, 16);
        $ciphertext = substr($raw, 28);
        $json = openssl_decrypt($ciphertext, 'aes-256-gcm', halkode_handoff_key(), OPENSSL_RAW_DATA, $iv, $tag);
        if ($json === false) {
            return new WP_Error('halkode_crypto', __('Ödeme aktarım verisi doğrulanamadı.', 'halkode'));
        }

        $payload = json_decode($json, true);
        if (!is_array($payload)) {
            return new WP_Error('halkode_crypto', __('Ödeme aktarım verisi çözümlenemedi.', 'halkode'));
        }

        return $payload;
    }

    function halkode_save_handoff($order_id, array $data)
    {
        try {
            $token = bin2hex(random_bytes(24));
        } catch (Exception $e) {
            return new WP_Error('halkode_handoff', __('Güvenli ödeme anahtarı üretilemedi.', 'halkode'));
        }

        $payload = [
            'created' => time(),
            'token_hash' => hash('sha256', $token),
            'data' => $data,
        ];
        $encrypted = halkode_encrypt_handoff($payload);
        if (is_wp_error($encrypted)) {
            return $encrypted;
        }

        update_post_meta((int)$order_id, 'halkode_payment_form', $encrypted);
        return $token;
    }

    function halkode_load_handoff($order_id, $token)
    {
        $encoded = get_post_meta((int)$order_id, 'halkode_payment_form', true);
        $payload = halkode_decrypt_handoff($encoded);
        if (is_wp_error($payload)) {
            return $payload;
        }

        if (empty($payload['created']) || (time() - (int)$payload['created']) > 300) {
            delete_post_meta((int)$order_id, 'halkode_payment_form');
            return new WP_Error('halkode_handoff', __('Ödeme aktarım süresi doldu. Lütfen tekrar deneyin.', 'halkode'));
        }

        $expected = isset($payload['token_hash']) ? (string)$payload['token_hash'] : '';
        $actual = hash('sha256', (string)$token);
        if ($expected === '' || !hash_equals($expected, $actual)) {
            return new WP_Error('halkode_handoff', __('Ödeme aktarım anahtarı geçersiz.', 'halkode'));
        }

        
        delete_post_meta((int)$order_id, 'halkode_payment_form');
        return isset($payload['data']) && is_array($payload['data']) ? $payload['data'] : new WP_Error('halkode_handoff', __('Ödeme aktarım verisi eksik.', 'halkode'));
    }

    function halkode_verified_status_matches_order($status, $order, $invoice_id)
    {
        if (!is_object($status) || !($order instanceof WC_Order)) {
            return false;
        }

        $expected_type = (string)$order->get_meta('_halkode_transaction_type');
        if ($expected_type === '') {
            $expected_type = 'Auth';
        }

        $status_code = (int)($status->status_code ?? 0);
        $is_auth_success = strcasecmp($expected_type, 'Auth') === 0 && $status_code === 100;
        $is_preauth_success = strcasecmp($expected_type, 'PreAuth') === 0 && in_array($status_code, [69, 100], true);

        if (!$is_auth_success && !$is_preauth_success) {
            return false;
        }

        $returned_invoice = (string)($status->invoice_id ?? '');
        if ($returned_invoice === '' || !hash_equals((string)$invoice_id, $returned_invoice)) {
            return false;
        }

        $provider_order_id = sanitize_text_field((string)($status->order_id ?? ''));
        if ($provider_order_id === '') {
            return false;
        }

        $transaction_status = sanitize_text_field((string)($status->transaction_status ?? ''));
        if (strcasecmp($expected_type, 'Auth') === 0) {
            if ($transaction_status !== '' && strcasecmp($transaction_status, 'Completed') !== 0) {
                return false;
            }
        } else {
            if ($transaction_status !== ''
                && !in_array(strtolower($transaction_status), ['pending', 'completed', 'approved', 'authorized'], true)) {
                return false;
            }
        }

        $expected_total = (float)$order->get_meta('_halkode_expected_total');
        if ($expected_total <= 0) {
            $expected_total = (float)$order->get_total();
        }

        if (isset($status->transaction_amount) && is_numeric($status->transaction_amount)) {
            if (abs((float)$status->transaction_amount - $expected_total) > 0.01) {
                return false;
            }
        }

        $returned_type = sanitize_text_field((string)($status->transaction_type ?? ''));
        if ($returned_type !== '' && strcasecmp($expected_type, $returned_type) !== 0) {
            return false;
        }

        $expected_installment = (int)$order->get_meta('_halkode_installments_number');
        $returned_installment = isset($status->installment) ? (int)$status->installment : 0;
        if ($expected_installment > 0 && $returned_installment > 0 && $expected_installment !== $returned_installment) {
            return false;
        }

        return true;
    }

    function halkode_empty_customer_cart()
    {
        if (!function_exists('WC')) {
            return;
        }

        
        
        if ((!WC()->session || !WC()->cart) && function_exists('wc_load_cart')) {
            wc_load_cart();
        }

        if (WC()->cart) {
            
            WC()->cart->empty_cart(true);
        }

        if (WC()->session) {
            
            WC()->session->set('cart', []);
            WC()->session->set('removed_cart_contents', []);
            WC()->session->set('applied_coupons', []);
            WC()->session->set('coupon_discount_totals', []);
            WC()->session->set('coupon_discount_tax_totals', []);
        }
    }

    function halkode_public_payment_error_message($technical_message, $md_status = '', $status_code = '', $bank_code = '')
    {
        $technical = mb_strtolower((string)$technical_message, 'UTF-8');

        
        $configuration_markers = [
            'bkm',
            'alt işyeri',
            'alt isyeri',
            'pf ',
            'merchant',
            'webhook',
            'işyeri',
            'isyeri',
            'terminal',
            'pos tanım',
            'pos tanim',
            'konfigürasyon',
            'configuration',
        ];

        foreach ($configuration_markers as $marker) {
            if (mb_strpos($technical, $marker, 0, 'UTF-8') !== false) {
                return __('Ödeme altyapısında geçici bir yapılandırma sorunu oluştu. Lütfen daha sonra tekrar deneyin veya mağaza ile iletişime geçin.', 'halkode');
            }
        }

        if ((string)$md_status === '0') {
            return __('3D Secure doğrulaması başlatılamadı. Lütfen kart bilgilerinizi kontrol edip tekrar deneyin.', 'halkode');
        }

        if ((string)$status_code === '41' || (string)$bank_code === '12') {
            return __('Ödeme bankanız tarafından onaylanmadı. Lütfen farklı bir kartla veya farklı bir ödeme seçeneğiyle tekrar deneyin.', 'halkode');
        }

        return __('Ödeme tamamlanamadı. Lütfen bilgilerinizi kontrol edip tekrar deneyin.', 'halkode');
    }

    function halkode_result_url($order, $state = 'success', $message = '')
    {
        if (!($order instanceof WC_Order)) {
            return home_url('/');
        }

        $args = [
            'halkode_result' => '1',
            'wc_order_id' => $order->get_id(),
            'wc_order_key' => $order->get_order_key(),
            'state' => sanitize_key($state),
        ];

        if ($message !== '') {
            $args['message'] = rawurlencode(wp_strip_all_tags($message));
        }

        return add_query_arg($args, home_url('/'));
    }

    function halkode_virtual_payment_result()
    {
        if (empty($_GET['halkode_result'])) {
            return;
        }

        $order_id = isset($_GET['wc_order_id']) ? absint($_GET['wc_order_id']) : 0;
        $order_key = isset($_GET['wc_order_key']) ? wc_clean(wp_unslash($_GET['wc_order_key'])) : '';
        $state = isset($_GET['state']) ? sanitize_key(wp_unslash($_GET['state'])) : 'success';
        $message = isset($_GET['message']) ? sanitize_text_field(rawurldecode(wp_unslash($_GET['message']))) : '';

        $order = $order_id ? wc_get_order($order_id) : false;

        if (!$order || !hash_equals((string) $order->get_order_key(), (string) $order_key)) {
            status_header(404);
            nocache_headers();
            echo '<!doctype html><html><head><meta charset="utf-8"><title>Ödeme sonucu</title></head><body style="font-family:Arial,sans-serif;padding:40px"><h1>Sipariş bulunamadı</h1><p>Ödeme sonucu doğrulanamadı.</p></body></html>';
            exit;
        }

        
        
        if ($order->is_paid()) {
            $state = 'success';
            halkode_empty_customer_cart();
        } elseif ($state === 'success') {
            $state = 'pending';
            $message = __('Ödeme henüz sunucu tarafından doğrulanmadı.', 'halkode');
        }

        nocache_headers();
        status_header(200);
        header('Content-Type: text/html; charset=' . get_option('blog_charset'));
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('Referrer-Policy: no-referrer');
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: DENY');

        $is_success = ($state === 'success');
        $is_pending = ($state === 'pending');
        $title = $is_success ? 'Ödemeniz başarıyla alındı' : ($is_pending ? 'Ödemeniz doğrulanıyor' : 'Ödeme tamamlanamadı');
        $detail = $message !== '' ? $message : ($is_success ? 'Siparişiniz başarıyla oluşturuldu.' : ($is_pending ? 'Banka onayı alındı. İşlem durumu kısa süre içinde kesinleşecektir.' : 'Ödeme işlemi başarısız oldu.'));
        $accent = $is_success ? '#16883f' : ($is_pending ? '#b7791f' : '#b42318');

        echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">';
        echo '<title>' . esc_html($title) . '</title>';
        echo '</head><body style="margin:0;background:#f4f7fb;font-family:Arial,sans-serif;color:#1f2937">';
        echo '<div style="max-width:720px;margin:70px auto;padding:0 18px">';
        echo '<div style="background:#fff;border:1px solid #e4eaf2;border-radius:20px;padding:34px;box-shadow:0 14px 38px rgba(20,40,70,.08)">';
        echo '<div style="font-size:44px;color:' . esc_attr($accent) . ';margin-bottom:10px">' . ($is_success ? '✓' : ($is_pending ? '…' : '×')) . '</div>';
        echo '<h1 style="margin:0 0 12px;font-size:28px">' . esc_html($title) . '</h1>';
        echo '<p style="font-size:16px;line-height:1.6;color:#5d6b7d">' . esc_html($detail) . '</p>';
        echo '<div style="margin-top:24px;padding:18px;background:#f8fafc;border-radius:14px">';
        echo '<div><strong>Sipariş:</strong> #' . esc_html($order->get_order_number()) . '</div>';
        echo '<div style="margin-top:8px"><strong>Tutar:</strong> ' . wp_kses_post($order->get_formatted_order_total()) . '</div>';
        echo '<div style="margin-top:8px"><strong>Durum:</strong> ' . esc_html(wc_get_order_status_name($order->get_status())) . '</div>';
        echo '</div>';
        echo '<div style="margin-top:26px"><a href="' . esc_url(home_url('/')) . '" style="display:inline-block;padding:12px 20px;background:#0b67c2;color:#fff;text-decoration:none;border-radius:10px;font-weight:700">Ana sayfaya dön</a></div>';
        echo '</div></div></body></html>';
        exit;
    }
    add_action('wp_ajax_delete_halkode_card', 'delete_halkode_card');
    add_action('wp_ajax_get_installment', 'get_installment');

    add_action('wp_ajax_nopriv_get_installment', 'get_installment');
    function halkode_pos()
    {
        
        if (!class_exists('WC_Payment_Gateway')) {
            return;
        }
        include_once 'halkode-woocommerce.php';
        include_once 'halkode-woocommerce-recurring.php';
        

        add_filter('woocommerce_payment_gateways', 'halkode_gateway');
        function halkode_gateway($methods)
        {
            $methods[] = 'halkode_sanalpos';
            return $methods;
        }
    }

    function delete_halkode_card()
    {
        check_ajax_referer('halkode_delete_card', 'nonce');
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => __('Yetkisiz işlem.', 'halkode')], 403);
        }

        $card = isset($_POST['card']) ? sanitize_text_field(wp_unslash($_POST['card'])) : '';
        if ($card === '') {
            wp_send_json_error(['message' => __('Kart seçilmedi.', 'halkode')], 400);
        }

        global $wpdb;
        $table = $wpdb->prefix . 'halkode_cards';
        $deleted = $wpdb->delete(
            $table,
            ['card_token' => $card, 'customer_id' => get_current_user_id()],
            ['%s', '%d']
        );

        if ($deleted === false) {
            wp_send_json_error(['message' => __('Kart silinemedi.', 'halkode')], 500);
        }
        wp_send_json_success();
    }



    add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'halkode_settings');
    function halkode_settings($links)
    {
        $plugin_links = ['<a href="' . admin_url('admin.php?page=wc-settings&tab=checkout&section=halkode_sanalpos') . '">' . __('Settings', 'halkode_sanalpos') . '</a>'];
        return array_merge($plugin_links, $links);
    }

    function getToken()
    {
        $halkode_pay = new halkode_sanalpos();
        $api_secret = $halkode_pay->get_option('app_secret');
        $api_key = $halkode_pay->get_option('app_key');
        $merchant_key = $halkode_pay->get_option('merchant_key');
        $merchant_id = $halkode_pay->get_option('merchant_id');
        $sandbox = $halkode_pay->get_option('environment');


        $url = $sandbox == 'yes' ? 'https://staging.halkode.com.tr/ccpayment/api/token' : 'https://app.halkode.com.tr/ccpayment/api/token';

        $array = [
            'app_id' => $api_key,
            'app_secret' => $api_secret
        ];

        return getCurl($url, 'POST', $array);

    }

    function checkStatus($invoice_id)
    {
        $halkode_pay = new halkode_sanalpos();
        $api_secret = $halkode_pay->get_option('app_secret');
        $api_key = $halkode_pay->get_option('app_key');
        $merchant_key = $halkode_pay->get_option('merchant_key');
        $merchant_id = $halkode_pay->get_option('merchant_id');
        $sandbox = $halkode_pay->get_option('environment');

        $hash_key = generateRefundHashKey($invoice_id, $merchant_key, $api_secret);
        $token_response = getToken();
        if (empty($token_response) || !isset($token_response->data) || !isset($token_response->data->token)) {
            return (object)[
                'status_code' => 0,
                'status_description' => __('Token alınamadı', 'halkode'),
            ];
        }
        $token = $token_response->data->token;
        $headers = ['Accept: application/json', 'Content-Type: application/json', "Authorization: Bearer {$token}"];
        $url = $sandbox == 'yes' ? 'https://staging.halkode.com.tr/ccpayment/api/checkstatus' : 'https://app.halkode.com.tr/ccpayment/api/checkstatus';

        $array = [
            'invoice_id' => $invoice_id,
            'merchant_key' => $merchant_key,
            'hash_key' => $hash_key,
            'include_pending_status' => "true",
        ];

        return getCurl($url, 'POST', json_encode($array), $headers);
    }

    function generateRefundHashKey($invoice_id, $merchant_key, $app_secret)
    {
        $data = $invoice_id . '|' . $merchant_key;
        try {
            $iv = bin2hex(random_bytes(8));
            $salt = bin2hex(random_bytes(2));
        } catch (Exception $e) {
            return '';
        }
        $password = sha1($app_secret);
        $saltWithPassword = hash('sha256', $password . $salt);
        $encrypted = openssl_encrypt(
            "$data", 'aes-256-cbc', "$saltWithPassword", 0, $iv
        );
        $msg_encrypted_bundle = "$iv:$salt:$encrypted";
        $hash_key = str_replace('/', '__', $msg_encrypted_bundle);
        return $hash_key;
    }

    function my_custom_public_page()
    {

        global $woocommerce;
        if (isset($_GET['action']) and ($_GET['action'] == 'woocommerce_get_order_details' or $_GET['action'] == 'woocommerce_mark_order_status'))
            return '';

        if (!empty($_GET['halkode_result'])) {
            return;
        }

        $is_handoff_request = isset($_GET['order_id'], $_GET['halkode_handoff']);
        $is_webhook_request = isset($_POST['webhook']) || isset($_GET['webhook']);
        $is_3d_callback_request = isset($_POST['halkode_3d_callback']) || isset($_GET['halkode_3d_callback']);

        if (!$is_handoff_request && !$is_webhook_request && !$is_3d_callback_request) {
            return;
        }

        $requestOrderId =  $_POST['order_id'] ?? $_GET['order_id'] ?? null;
        $requestInvoiceId =  $_POST['invoice_id'] ?? $_GET['invoice_id'] ?? null;
        $requestPaymentStatus =  $_POST['payment_status'] ?? $_GET['payment_status'] ?? null;
        $callbackOrderId = isset($_POST['wc_order_id'])
            ? absint($_POST['wc_order_id'])
            : (isset($_GET['wc_order_id']) ? absint($_GET['wc_order_id']) : 0);
        $callbackOrderKey = isset($_POST['wc_order_key'])
            ? wc_clean(wp_unslash($_POST['wc_order_key']))
            : (isset($_GET['wc_order_key']) ? wc_clean(wp_unslash($_GET['wc_order_key'])) : '');

        if (isset($requestOrderId) && !isset($requestInvoiceId)) {
            $handoff_token = isset($_GET['halkode_handoff']) ? sanitize_text_field(wp_unslash($_GET['halkode_handoff'])) : '';
            $handoff = halkode_load_handoff(absint($requestOrderId), $handoff_token);
            if (is_wp_error($handoff)) {
                wc_add_notice($handoff->get_error_message(), 'error');
                wp_safe_redirect(wc_get_checkout_url());
                exit;
            }

            $handoff_type = isset($handoff['type']) ? (string)$handoff['type'] : '';

            if ($handoff_type === 'bank_html') {
                $bank_html = isset($handoff['html']) && is_string($handoff['html']) ? $handoff['html'] : '';

                if ($bank_html === '' || stripos($bank_html, '<form') === false) {
                    wc_add_notice(__('Banka 3D Secure sayfası oluşturulamadı.', 'halkode'), 'error');
                    wp_safe_redirect(wc_get_checkout_url());
                    exit;
                }

                nocache_headers();
                header('Content-Type: text/html; charset=UTF-8');
                header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
                header('Pragma: no-cache');
                header('Referrer-Policy: no-referrer');
                header('X-Content-Type-Options: nosniff');
                header('X-Frame-Options: DENY');
                header("Content-Security-Policy: default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: https:; form-action https:; connect-src 'none'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'");

                echo $bank_html;
                exit;
            }

            wc_add_notice(__('Geçersiz veya artık desteklenmeyen ödeme aktarımı.', 'halkode'), 'error');
            wp_safe_redirect(wc_get_checkout_url());
            exit;

        }

        $requestWebhook =  $_POST['webhook'] ?? $_GET['webhook'] ?? null;

        if (isset($requestWebhook) && (string)$requestWebhook === '1') {
            if (!is_string($requestInvoiceId) || strpos($requestInvoiceId, 'WOO') === false) {
                status_header(400);
                exit;
            }

            $parts = explode('WOO', $requestInvoiceId);
            $webhook_order_id = absint(end($parts));
            $customer_order = $webhook_order_id ? wc_get_order($webhook_order_id) : false;
            if (!$customer_order) {
                status_header(404);
                exit;
            }

            $expected_invoice = (string)$customer_order->get_meta('_halkode_invoice_id');
            if ($expected_invoice === '' || !hash_equals($expected_invoice, (string)$requestInvoiceId)) {
                status_header(403);
                exit;
            }

            
            $verified = checkStatus($requestInvoiceId);
            $verified_code = is_object($verified) ? (int)($verified->status_code ?? 0) : 0;
            if (halkode_verified_status_matches_order($verified, $customer_order, $requestInvoiceId)) {
                $reference = isset($verified->order_id) ? sanitize_text_field((string)$verified->order_id) : '';
                if (!$customer_order->is_paid()) {
                    $customer_order->payment_complete($reference);
                }
                $customer_order->add_order_note(__('HalkÖde webhook sunucu doğrulaması başarılı. Referans: ', 'halkode') . $reference);
                status_header(200);
                exit;
            }

            $customer_order->add_order_note(__('HalkÖde webhook alındı ancak checkStatus ile doğrulanamadı; sipariş durumu değiştirilmedi.', 'halkode'));
            status_header(202);
            exit;
        }

        $resolved_order_id = 0;
        if ($callbackOrderId > 0) {
            $candidate_order = wc_get_order($callbackOrderId);
            if ($candidate_order && $callbackOrderKey !== '' && hash_equals((string)$candidate_order->get_order_key(), (string)$callbackOrderKey)) {
                $resolved_order_id = $callbackOrderId;
            }
        }

        if (!$resolved_order_id && isset($requestInvoiceId) && strstr((string)$requestInvoiceId, 'WOO')) {
            $invoice_parts = explode('WOO', (string)$requestInvoiceId);
            $invoice_order_id = absint(end($invoice_parts));
            $invoice_order = $invoice_order_id ? wc_get_order($invoice_order_id) : false;

            if ($invoice_order) {
                $expected_invoice = (string)$invoice_order->get_meta('_halkode_invoice_id');
                if ($expected_invoice !== '' && hash_equals($expected_invoice, (string)$requestInvoiceId)) {
                    $resolved_order_id = $invoice_order_id;
                }
            }
        }

        if ($resolved_order_id) {
            $resolved_order = wc_get_order($resolved_order_id);
            $expected_invoice = $resolved_order ? (string)$resolved_order->get_meta('_halkode_invoice_id') : '';

            if (!$resolved_order || !is_string($requestInvoiceId) || $expected_invoice === '' || !hash_equals($expected_invoice, $requestInvoiceId)) {
                status_header(403);
                exit;
            }
        }

        $requestStatusCode = $_POST['status_code'] ?? $_GET['status_code'] ?? null;
        $requestStatusDescription = $_POST['status_description'] ?? $_GET['status_description'] ?? '';
        $requestErrorCode = $_POST['error_code'] ?? $_GET['error_code'] ?? '';
        $requestError = $_POST['error'] ?? $_GET['error'] ?? '';
        $originalBankErrorCode = $_POST['original_bank_error_code'] ?? $_GET['original_bank_error_code'] ?? '';
        $originalBankErrorDescription = $_POST['original_bank_error_description'] ?? $_GET['original_bank_error_description'] ?? '';
        $mdStatus = $_POST['md_status'] ?? $_GET['md_status'] ?? '';

        if ($resolved_order_id && isset($requestPaymentStatus) && (string)$requestPaymentStatus === '1') {
            $customer_order = wc_get_order($resolved_order_id);

            if (!$customer_order) {
                wp_safe_redirect(home_url('/'));
                exit;
            }

            $status = null;
            for ($attempt = 0; $attempt < 3; $attempt++) {
                $status = checkStatus($requestInvoiceId);
                if (halkode_verified_status_matches_order($status, $customer_order, $requestInvoiceId)) {
                    break;
                }
                if ($attempt < 2) {
                    usleep(500000);
                }
            }

            if (halkode_verified_status_matches_order($status, $customer_order, $requestInvoiceId)) {
                $transaction_id = '';
                if (is_object($status) && isset($status->order_id)) {
                    $transaction_id = sanitize_text_field((string)$status->order_id);
                }

                if (!$customer_order->is_paid()) {
                    $customer_order->payment_complete($transaction_id);
                }

                $customer_order->add_order_note(
                    sprintf(
                        'HalkÖde 3D başarılı. Taksit: %s | status_code: %s | md_status: %s | ref: %s',
                        $customer_order->get_meta('_halkode_installments_number') ?: '1',
                        sanitize_text_field((string)$requestStatusCode),
                        sanitize_text_field((string)$mdStatus),
                        $transaction_id
                    )
                );

                delete_post_meta($resolved_order_id, 'halkode_payment_form');
                delete_post_meta($resolved_order_id, 'halkode_response');

                
                halkode_empty_customer_cart();

                wp_safe_redirect(halkode_result_url($customer_order, 'success', '3D Secure doğrulaması ve ödeme başarıyla tamamlandı.'));
                exit;
            }

            $pending_technical = is_object($status) && !empty($status->status_description)
                ? (string)$status->status_description
                : ($requestStatusDescription ?: 'Banka doğrulaması alındı; ödeme durumu sistemde doğrulanıyor.');

            if (!$customer_order->has_status(['processing', 'completed'])) {
                $customer_order->update_status('on-hold', '3D Secure dönüşü alındı; HalkÖde işlem durumu doğrulaması bekleniyor.');
            }

            $customer_order->add_order_note(
                'HalkÖde doğrulama bekliyor. Teknik durum: ' . sanitize_text_field($pending_technical)
            );

            $pending_message = __('Ödeme doğrulaması alındı. İşlem sonucu kontrol ediliyor; lütfen kısa süre sonra sipariş durumunu tekrar kontrol edin.', 'halkode');
            wp_safe_redirect(halkode_result_url($customer_order, 'pending', $pending_message));
            exit;
        }

        
        $looks_like_failure = (
            isset($requestPaymentStatus) && (string)$requestPaymentStatus === '0'
        ) || (
            $requestStatusCode !== null && (int)$requestStatusCode !== 100
        ) || $requestError !== '' || $originalBankErrorDescription !== '';

        if ($resolved_order_id && $looks_like_failure) {
            $customer_order = wc_get_order($resolved_order_id);

            $parts = [];
            if ($requestStatusDescription !== '') {
                $parts[] = sanitize_text_field((string)$requestStatusDescription);
            }
            if ($requestError !== '' && $requestError !== $requestStatusDescription) {
                $parts[] = sanitize_text_field((string)$requestError);
            }
            if ($originalBankErrorDescription !== '' && $originalBankErrorDescription !== $requestError) {
                $parts[] = 'Banka: ' . sanitize_text_field((string)$originalBankErrorDescription);
            }

            $codes = [];
            if ($requestStatusCode !== null && $requestStatusCode !== '') {
                $codes[] = 'status_code=' . sanitize_text_field((string)$requestStatusCode);
            }
            if ($requestErrorCode !== '') {
                $codes[] = 'error_code=' . sanitize_text_field((string)$requestErrorCode);
            }
            if ($originalBankErrorCode !== '') {
                $codes[] = 'bank_code=' . sanitize_text_field((string)$originalBankErrorCode);
            }
            if ($mdStatus !== '') {
                $codes[] = 'md_status=' . sanitize_text_field((string)$mdStatus);
            }

            $technical_message = trim(implode(' | ', array_filter([
                implode(' — ', $parts),
                implode(', ', $codes),
            ])));

            if ($technical_message === '') {
                $technical_message = '3D Secure ödeme banka/HalkÖde tarafından reddedildi.';
            }

            $public_message = halkode_public_payment_error_message(
                $technical_message,
                $mdStatus,
                $requestStatusCode,
                $originalBankErrorCode
            );

            if ($customer_order) {
                
                update_post_meta($resolved_order_id, 'halkode_response', $public_message);

                
                $customer_order->add_order_note(
                    'HalkÖde 3D başarısız. Taksit: ' .
                    ($customer_order->get_meta('_halkode_installments_number') ?: '1') .
                    ' | ' . $technical_message
                );

                delete_post_meta($resolved_order_id, 'halkode_payment_form');

                wp_safe_redirect(halkode_result_url($customer_order, 'failed', $public_message));
                exit;
            }
        }

    }


    function get_installment()
    {
        check_ajax_referer('halkode_get_installment', 'nonce');

        $remote_addr = isset($_SERVER['REMOTE_ADDR']) ? (string)$_SERVER['REMOTE_ADDR'] : 'unknown';
        $rate_key = 'halkode_gp_' . substr(hash_hmac('sha256', $remote_addr, wp_salt('nonce')), 0, 32);
        $rate_count = (int)get_transient($rate_key);
        if ($rate_count >= 30) {
            wp_send_json_error(['message' => __('Çok fazla taksit sorgusu. Lütfen kısa süre sonra tekrar deneyin.', 'halkode')], 429);
        }
        set_transient($rate_key, $rate_count + 1, MINUTE_IN_SECONDS);

        $raw_card_number = isset($_POST['cc_number']) ? preg_replace('/\D+/', '', (string)wp_unslash($_POST['cc_number'])) : '';
        $card_bin = substr($raw_card_number, 0, 6);
        if (!preg_match('/^\d{6}$/', $card_bin)) {
            wp_send_json(['data' => '', 'options' => []]);
        }

        if (!function_exists('WC') || !WC()->cart) {
            wp_send_json(['data' => '', 'options' => []]);
        }

        $halkode_pay = new halkode_sanalpos();
        $token_response = getToken();
        $token = is_object($token_response) && isset($token_response->data->token)
            ? sanitize_text_field((string)$token_response->data->token)
            : '';
        if ($token === '') {
            wp_send_json(['data' => '', 'options' => []]);
        }

        $pos_post = [
            'credit_card' => $card_bin,
            'amount' => number_format((float)WC()->cart->total, 2, '.', ''),
            'currency_code' => $halkode_pay->get_wc_currency(),
            'merchant_key' => $halkode_pay->get_option('merchant_key'),
        ];

        if (!empty($_POST['recurring_options']['recurring_check']) && sanitize_text_field(wp_unslash($_POST['recurring_options']['recurring_check'])) === 'yes') {
            $pos_post['is_recurring'] = 1;
        }

        $environment = $halkode_pay->get_option('environment') == 'yes' ? 'TRUE' : 'FALSE';
        $environment_url = 'FALSE' == $environment
            ? 'https://app.halkode.com.tr/ccpayment/api/getpos'
            : 'https://staging.halkode.com.tr/ccpayment/api/getpos';

        $headers = ['Accept: application/json', 'Content-Type: application/json', 'Authorization: Bearer ' . $token];
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $environment_url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, wp_json_encode($pos_post));
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);

        $raw_response = curl_exec($ch);
        curl_close($ch);
        if ($raw_response === false) {
            wp_send_json(['data' => '', 'options' => [], 'message' => __('Taksit servisine ulaşılamadı.', 'halkode')]);
        }

        $get_pos_response = json_decode($raw_response, true);
        if (!is_array($get_pos_response) || (int)($get_pos_response['status_code'] ?? 0) !== 100 || empty($get_pos_response['data']) || !is_array($get_pos_response['data'])) {
            wp_send_json(['data' => '', 'options' => []]);
        }

        $html = "<div class='row'>";
        $options = [];
        $first = [];
        $allowed_installments = $halkode_pay->get_option('installments');
        if (!is_array($allowed_installments)) {
            $allowed_installments = array_filter(array_map('trim', explode(',', (string)$allowed_installments)));
        }

        foreach ($get_pos_response['data'] as $index => $val) {
            $installment_no = max(1, (int)($val['installments_number'] ?? 1));
            if (!empty($allowed_installments) && !in_array((string)$installment_no, array_map('strval', $allowed_installments), true)) {
                continue;
            }

            $currency_code = sanitize_text_field((string)($val['currency_code'] ?? ''));
            $amount = (string)($val['amount_to_be_paid'] ?? '');
            $label = empty($options)
                ? $halkode_pay->getLocalizationContent('single_installment', $currency_code)
                : $installment_no . ' ' . $halkode_pay->getLocalizationContent('installment', $currency_code);
            $per_installment = number_format(((float)$amount) / $installment_no, 2, '.', '');

            $option = [
                'pos_id' => sanitize_text_field((string)($val['pos_id'] ?? '')),
                'amount' => sanitize_text_field($amount),
                'installments_number' => (string)$installment_no,
                'currency_code' => $currency_code,
                'label' => sanitize_text_field((string)$label),
                'per_installment' => $per_installment,
            ];
            if (empty($first)) {
                $first = $option;
            }
            $options[] = $option;

            $html .= "<div class='single-installment " . (count($options) === 1 ? 'active' : '') . "'" .
                " data-installments_number='" . esc_attr($option['installments_number']) . "'>" .
                "<div class='halkode_heading'>" . esc_html($option['label']) . "</div>" .
                "<div class='halkode_amount'>" . esc_html($option['amount']) . ' ' . esc_html($option['currency_code']) . "</div>" .
                "<div class='halkode_installment_number'>" . esc_html($option['installments_number']) . " X</div>" .
                "<div class='halkode_total_amount'>" . esc_html($option['per_installment']) . ' ' . esc_html($option['currency_code']) . "</div></div>";
        }
        $html .= '</div>';

        wp_send_json([
            'data' => $html,
            'installments_number' => $first['installments_number'] ?? '',
            'options' => $options,
        ]);
    }


    function getCurl($url, $method, $array, $header = [])
    {
        if (!halkode_is_allowed_remote_url($url)) {
            return (object)['status_code' => 0, 'status_description' => __('Geçersiz uzak API adresi.', 'halkode')];
        }

        $curl = curl_init();
        $options = [
            CURLOPT_URL => $url,
            CURLOPT_HTTPHEADER => $header,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 0,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_POSTFIELDS => $array,
        ];
        if (defined('CURLPROTO_HTTPS')) {
            $options[CURLOPT_PROTOCOLS] = CURLPROTO_HTTPS;
        }

        curl_setopt_array($curl, $options);
        $response = curl_exec($curl);
        $errno = curl_errno($curl);
        curl_close($curl);

        if ($response === false || $errno) {
            return (object)['status_code' => 0, 'status_description' => __('Ödeme servisine güvenli bağlantı kurulamadı.', 'halkode')];
        }

        $decoded = json_decode($response);
        return is_object($decoded)
            ? $decoded
            : (object)['status_code' => 0, 'status_description' => __('Ödeme servisinden geçersiz yanıt alındı.', 'halkode')];
    }


