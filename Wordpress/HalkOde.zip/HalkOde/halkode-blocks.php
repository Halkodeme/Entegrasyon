<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class Halkode_Blocks_Payment_Method extends AbstractPaymentMethodType {
    protected $name = 'halkode_sanalpos';

    public function initialize() {
        $this->settings = get_option( 'woocommerce_halkode_sanalpos_settings', array() );
    }

    public function is_active() {
        return ! empty( $this->settings['enabled'] ) && 'yes' === $this->settings['enabled'];
    }

    public function get_payment_method_script_handles() {
        $handle = 'halkode-blocks-integration';
        wp_register_script(
            $handle,
            plugins_url( 'js/halkode-blocks.js', __FILE__ ),
            array( 'wc-blocks-registry', 'wc-settings', 'wp-element', 'wp-html-entities' ),
            '2.2.0',
            true
        );
        return array( $handle );
    }

    public function get_payment_method_data() {
        $is_3d = 1;

        return array(
            'title'       => $this->settings['title'] ?? __( 'Halk Ödeme Hizmetleri Pos', 'halkode' ),
            'description' => $this->settings['description'] ?? '',
            'supports'    => array( 'products' ),
            'is_3d'       => 1,
            'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
            'logoUrl'     => plugins_url( 'images/halkode-logo.png', __FILE__ ),
            'installmentNonce' => wp_create_nonce( 'halkode_get_installment' ),
        );
    }
}
