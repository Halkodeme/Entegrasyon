<?php

    if (!defined('ABSPATH')) {
        exit;
    }

    class halkode_sanalpos extends WC_Payment_Gateway
    {

        public $merchant_key;
        public $app_key;
        public $app_secret;
        public $merchant_id;
        public $sale_webhook_key;
        public $recurring_sale_webhook_key;
        public $environment;
        public $transaction_type;
        public $installments;

        protected $is_3d = 0;
        public $headers = array(

            'Accept: application/json',

            'Content-Type: application/json'

        );

        function __construct()
        {
            
            $this->id = "halkode_sanalpos";
            
            $this->method_title = __("Halk Ödeme Hizmetleri", 'halkode');
            
            $this->method_description = __("Woocommerce için Halk Ödeme Hizmetleri Entegrasyonu", 'halkode');
            
            $this->title = __("Halk Ödeme Hizmetleri Pos", 'halkode');
            $this->icon = null;
            $this->has_fields = true;
            
            
            
            $this->init_form_fields();
            
            $this->init_settings();


            
            foreach ($this->settings as $setting_key => $value) {
                $this->$setting_key = $value;
            }

            
            add_action('admin_notices', [$this, 'do_ssl_check']);
            add_action('wp_enqueue_scripts', array($this, 'payment_scripts'));

            
            if (is_admin()) {
                $this->activate();
                add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
            }
        } 

        

        function activate()
        {
            if (get_option('halkode_db_schema_version') === '1') {
                return;
            }

            global $wpdb;
            $table_name = $wpdb->prefix . 'halkode_cards';
            $charset_collate = $wpdb->get_charset_collate();

            $sql = "CREATE TABLE IF NOT EXISTS $table_name (
                card_id int(11) NOT NULL AUTO_INCREMENT,
                customer_id INT(11) NOT NULL,
                card_token varchar(255) NOT NULL,
                card_mask varchar(255) NOT NULL,
                created_at timestamp DEFAULT current_timestamp,
                PRIMARY KEY (card_id),
                KEY customer_id (customer_id)
            ) $charset_collate;";

            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

            try {
                dbDelta($sql);
                update_option('halkode_db_schema_version', '1', false);
            } catch (\Exception $e) {
            }
        }

        public function init_form_fields()
        {

            $installments = $this->get_admin_installment();
            $this->form_fields = [

                'merchant_key' => [
                    'title' => __('Merchant Key', 'halkode'),
                    'type' => 'text',
                    'desc_tip' => __('Merchant Key', 'halkode'),
                ],
                'app_key' => [
                    'title' => __('App Key', 'halkode'),
                    'type' => 'text',
                    'desc_tip' => __('App key', 'halkode'),
                ],
                'app_secret' => [
                    'title' => __('App Secret', 'halkode'),
                    'type' => 'password',
                    'desc_tip' => __('App Secret', 'halkode'),
                ],
                'merchant_id' => [
                    'title' => __('Merchant ID', 'halkode'),
                    'type' => 'text',
                    'desc_tip' => __('Merchant ID', 'halkode'),
                ],
                'sale_webhook_key' => [
                    'title' => __('Satış Webhook Anahtarı', 'halkode'),
                    'type' => 'text',
                    'desc_tip' => __('Satış Webhook Anahtarı', 'halkode'),
                    'description' => get_site_url() . '?webhook=1',
                ],
                'recurring_sale_webhook_key' => [
                    'title' => __('Yinelenen Satış Webhook Anahtarı', 'halkode'),
                    'type' => 'text',
                    'desc_tip' => __('Yinelenen Satış Webhook Anahtarı', 'halkode'),
                    'description' => get_site_url() . '?webhook=1&recurring=1',
                ],
                'environment' => [
                    'title' => __('HalkÖde Ortamı', 'halkode'),
                    'type' => 'select',
                    'default' => 'yes',
                    'options' => [
                        'yes' => __('Staging / Test', 'halkode'),
                        'no' => __('Canlı / Production', 'halkode'),
                    ],
                    'description' => __('Staging / Test seçildiğinde staging.halkode.com.tr kullanılır. Canlı / Production seçildiğinde app.halkode.com.tr kullanılır ve HTTPS zorunludur.', 'halkode'),
                ],
                'transaction_type' => array(
                    'title' => __('Provizyon Türü', 'halkode'),
                    'type' => 'select',
                    'default' => 'Auth',
                    'options' => array('Auth' => __('Auth', 'halkode'), 'PreAuth' => __('PreAuth', 'halkode'))
                ),
                'installments' => array(
                    'title' => 'Taksit Sayısı',
                    'type' => 'multiselect',
                    'options' => $installments,
                    'description' => __('Shift ile çoklu seçim yapabilirsiniz.', 'halkode'),
                    'custom_attributes' => array(
                        'data-placeholder' => __('Taksit Seçiniz', 'halkode'),
                    ),
                ),
                'enabled' => [
                    'title' => __('Ödeme Yöntemi <br> Etkin/Pasif', 'halkode'),
                    'label' => __('Bu yöntemi etkinleştir', 'halkode'),
                    'type' => 'checkbox',
                    'default' => 'no',
                ],
                'title' => [
                    'title' => __('Başlık', 'halkode'),
                    'type' => 'text',
                    'desc_tip' => __('Başlık', 'halkode'),
                    'default' => __('Halk Ödeme Hizmetleri', 'halkode'),
                ],
                'description' => [
                    'title' => __('Açıklama', 'halkode'),
                    'type' => 'textarea',
                    'desc_tip' => __('Açıklama', 'halkode'),
                    'default' => __('Kredi kartıyla ödeme yap', 'halkode'),
                    'css' => 'max-width:450px;',
                ],


            ];
        }

        public function getLocalizationContent($content, $language)
        {
            $language = strtoupper($language);

            $lang = [
                get_option('woocommerce_currency') => [
                    'card_holder_name' => 'Kart Sahibi',

                    'card_number' => 'Kart Numarası',

                    'expiry' => 'Son Kullanma Tarihi',

                    'cvv' => 'Güvenlik Numarası',

                    'single_installment' => 'Peşin',

                    'installment' => 'Taksit',

                    'new_card' => 'Yeni Kart',

                    'saved_card' => 'Kayıtlı Kart',

                    'save_card' => 'Bu Kartı Kaydet',

                    '3D_payment' => '3D Ödeme',

                    'your_registered_cards' => 'Kayıtlı Kartlarınız',

                    'choose_card' => 'Kart Seçiniz',

                    'no_registered_card' => 'Kayıtlı Kartınız Yok',

                    'delete_saved_card' => 'Sil',
                ],

                'USD' => [
                    'card_holder_name' => 'Card Holder Name',

                    'card_number' => 'Card Number',

                    'expiry' => 'Expiry',

                    'cvv' => 'CVV',

                    'single_installment' => 'Single Installment',

                    'installment' => 'Installment',

                    'new_card' => 'New Card',

                    'saved_card' => 'Saved Card',

                    'save_card' => 'Save Card',

                    '3D_payment' => '3D Payment',

                    'your_registered_cards' => 'Your Registered Cards',

                    'choose_card' => 'Choose Card',

                    'no_registered_card' => 'You Dont Have a Registered Card',

                    'delete_saved_card' => 'Delete',
                ],

                'EUR' => [
                    'card_holder_name' => 'Card Holder Name',

                    'card_number' => 'Card Number',

                    'expiry' => 'Expiry',

                    'cvv' => 'CVV',

                    'single_installment' => 'Single Installment',

                    'installment' => 'Installment',

                    'new_card' => 'New Card',

                    'saved_card' => 'Saved Card',

                    'save_card' => 'Save Card',

                    '3D_payment' => '3D Payment',

                    'your_registered_cards' => 'Your Registered Cards',

                    'choose_card' => 'Choose Card',

                    'no_registered_card' => 'You Dont Have a Registered Card',

                    'delete_saved_card' => 'Delete',
                ],
            ];

            if (!isset($lang[$language])) {
                $language = 'USD';
            }

            if (isset($lang[$language][$content])) {
                $localizeContent = $lang[$language][$content];
            } else {
                $localizeContent = $content;
            }

            return $localizeContent;
        }

        public function payment_fields()
        {

            if ($description = $this->get_description()) {
                echo wpautop(wptexturize($description));
            }

            $currency = $this->get_wc_currency();

            

            $this->is_3d = 1;
            echo '<fieldset id="wc-' . esc_attr($this->id) . '-cc-form" class="wc-credit-card-form wc-payment-form" style="background:transparent;">';

            if (!empty(WC()->cart->get_cart())) {
                foreach (WC()->cart->get_cart() as $cart_item) {
                    $cart_product_id = $cart_item['product_id'];
                    $is_recurring_cart = get_post_meta($cart_product_id, "_recurring", true);

                    if ($is_recurring_cart == 'yes') {
                        $payment_duration = get_post_meta($cart_product_id, "payment_duration", true);
                        $payment_cycle = get_post_meta($cart_product_id, "payment_cycle", true);
                        $payment_interval = get_post_meta($cart_product_id, "payment_interval", true);

                        if (!empty($payment_duration) && !empty($payment_cycle) && !empty($payment_interval)) { ?>
                            <input class="recurring_checkbox" name="recurring_options[recurring_check]" type="hidden" value="yes">
                            <input type="hidden" name="recurring_options[payment_duration]" class="payment_duration" value="<?php echo esc_attr($payment_duration); ?>"/>
                            <input type="hidden" name="recurring_options[payment_cycle]" class="payment_cycle" value="<?php echo esc_attr($payment_cycle); ?>"/>
                            <input type="hidden" name="recurring_options[payment_interval]" class="payment_interval" value="<?php echo esc_attr($payment_interval); ?>"/>
                        <?php }
                    }
                }
            }

            $this->is_3d = 1;
            echo "<input type='hidden' name='halkode_3d' class='halkode_3d' id='halkode_3d' value='1'/>";
            {
                

                do_action('woocommerce_credit_card_form_start', $this->id);
                
                ?>
                <input type="hidden" class="stored_card" name="stored_card" value="0">

                <div class="payment-form halkode-checkout-card">
                    <div class="halkode-card-shell">
                        <div class="halkode-card-header">
                            <div class="halkode-card-title-group">
                                <div class="halkode-card-title"><?php echo esc_html($this->get_title()); ?></div>
                                <div class="halkode-card-subtitle">Kart numaranızın ilk 6 hanesi girildiğinde taksit seçenekleri /api/getpos üzerinden otomatik sorgulanır.</div>
                            </div>
                            <div class="halkode-card-logo-wrap">
                                <img class="halkode-card-logo" src="<?php echo esc_url(plugins_url('images/halkode-logo.png', __FILE__)); ?>" alt="Halk Öde">
                            </div>
                        </div>

                        <div class="halkode-field-grid">
                            <p class="form-row form-row-wide halkode-field-group">
                                <label><?php echo $this->getLocalizationContent('card_holder_name', $currency); ?> <span class="required">*</span></label>
                                <input id="cc_holder_name" name="cc_holder_name" class="input-text cc_holder_name alpha-only" type="text" autocomplete="cc-name" maxlength="80" placeholder="Ad Soyad">
                            </p>

                            <p class="form-row form-row-wide halkode-field-group halkode-card-number-wrap">
                                <label><?php echo $this->getLocalizationContent('card_number', $currency); ?> <span class="required">*</span></label>
                                <input id="cc_number" class="input-text cc_number" name="cc_number" type="text" inputmode="numeric" maxlength="19" autocomplete="cc-number" placeholder="0000000000000000">
                                <span class="halkode_spinner_blk"></span>
                            </p>

                            <div class="halkode-field-row">
                                <p class="form-row form-row-first halkode-field-group halkode-expiry-wrap">
                                    <label><?php echo $this->getLocalizationContent('expiry', $currency); ?> <span class="required">*</span></label>
                                    <div class="halkode-expiry-selects">
                                        <select name="expiry_month" id="expiry_month" class="input-select">
                                            <?php for ($i = 1; $i <= 12; $i++) { echo '<option value="' . $i . '" >' . str_pad($i, 2, '0', STR_PAD_LEFT) . '</option>'; } ?>
                                        </select>
                                        <select name="expiry_year" id="expiry_year" class="input-select">
                                            <?php for ($i = date('Y'); $i <= date('Y') + 10; $i++) { echo '<option value="' . $i . '" >' . $i . '</option>'; } ?>
                                        </select>
                                    </div>
                                </p>

                                <p class="form-row form-row-last halkode-field-group halkode-cvv-wrap">
                                    <label><?php echo $this->getLocalizationContent('cvv', $currency); ?> <span class="required">*</span></label>
                                    <input id="cc_cvv" class="input-text cc_cvv" name="cc_cvv" type="password" maxlength="4" inputmode="numeric" autocomplete="cc-csc" placeholder="CVV">
                                </p>
                            </div>
                        </div>

                        <div class="halkode-installment-box is-hidden" id="halkode-installment-box">
                            <div class="halkode-installment-head">
                                <div>
                                    <strong>Taksit Seçenekleri</strong>
                                    <span>Kart bilgisi algılandığında uygun taksit seçenekleri aşağıda görünür.</span>
                                </div>
                            </div>
                            <p class="installments form-row form-row-wide" id="installments"></p>
                        </div>
                    </div>

                    <input type="hidden" name="installments_number" class="installments_number" value="1"/>

                    <div class="clear"></div>

                    <div class="clear"></div>

					<?php
					
					?>
					
                </div>
                <div class="clear"></div>

                <input type="hidden" id="pay_via_3d" class="pay_via_3d" name="pay_via_3d" value="yes">
                <p class="form-row form-row-wide halkode-3d-toggle">
                    <strong>✓ 3D Secure zorunlu güvenli ödeme</strong>
                </p>

                <?php
                
                ?>

                <?php
                do_action('woocommerce_credit_card_form_end', $this->id);


                echo '<div class="clear"></div></fieldset>';

            }
        }


        public function payment_scripts()
        {


            if (!is_cart() && !is_checkout() && !isset($_GET['pay_for_order'])) {

                return;

            }
            if ('no' === $this->enabled) {

                return;

            }

            wp_register_script('woocommerce_halkode', plugins_url('js/halkode.js', __FILE__), ['jquery'], '2.4.0', true);

            wp_localize_script('woocommerce_halkode', 'halkode_var', array('spinner' => plugins_url('images/spinner.gif', __FILE__), 'installmentNonce' => wp_create_nonce('halkode_get_installment'), 'deleteCardNonce' => wp_create_nonce('halkode_delete_card')));

            wp_enqueue_script('woocommerce_halkode');

            wp_enqueue_style('woocommerce_halkode_style', plugins_url('css/halkode.css', __FILE__), [], '2.4.0');

        }

        public function curl($url, $method, $array, $header = [])
        {
            if (!halkode_is_allowed_remote_url($url)) {
                return (object)['status_code' => 0, 'status_description' => __('Geçersiz uzak API adresi.', 'halkode')];
            }

            $curl = curl_init();
            $options = [
                CURLOPT_URL => $url,
                CURLOPT_HTTPHEADER => $header,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 0,
                CURLOPT_CONNECTTIMEOUT => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_SSL_VERIFYHOST => 2,
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => $method,
                CURLOPT_POSTFIELDS => $array,
            ];
            if (defined('CURLPROTO_HTTPS')) {
                $options[CURLOPT_PROTOCOLS] = CURLPROTO_HTTPS;
            }

            curl_setopt_array($curl, $options);
            $response = curl_exec($curl);
            $errno = curl_errno($curl);
            curl_close($curl);

            if ($response === false || $errno) {
                return (object)['status_code' => 0, 'status_description' => __('Ödeme servisine güvenli bağlantı kurulamadı.', 'halkode')];
            }

            $decoded = json_decode($response);
            return is_object($decoded)
                ? $decoded
                : (object)['status_code' => 0, 'status_description' => __('Ödeme servisinden geçersiz yanıt alındı.', 'halkode')];
        }


        
        public function process_payment($order_id)
        {

            global $woocommerce;

            global $wp_session;
            $order = new WC_Order($order_id);

            
            $remote_addr = isset($_SERVER['REMOTE_ADDR']) ? (string)$_SERVER['REMOTE_ADDR'] : 'unknown';
            $rate_subject = get_current_user_id() > 0 ? 'u:' . get_current_user_id() : 'ip:' . $remote_addr;
            $payment_rate_key = 'halkode_pay_' . substr(hash_hmac('sha256', $rate_subject, wp_salt('nonce')), 0, 32);
            $payment_attempts = (int)get_transient($payment_rate_key);
            if ($payment_attempts >= 20) {
                wc_add_notice(__('Çok fazla ödeme denemesi yapıldı. Lütfen birkaç dakika sonra tekrar deneyin.', 'halkode'), 'error');
                return ['result' => 'failure'];
            }
            set_transient($payment_rate_key, $payment_attempts + 1, 10 * MINUTE_IN_SECONDS);

            $environment = $this->get_option('environment') == "yes" ? 'TRUE' : 'FALSE';

            if ("FALSE" == $environment && !halkode_is_local_host() && !is_ssl()) {
                wc_add_notice(__('Canlı HalkÖde ödemeleri gerçek alan adında yalnızca HTTPS üzerinden başlatılabilir.', 'halkode'), 'error');
                return ['result' => 'failure'];
            }

            if (isset($_POST['stored_card']) && absint($_POST['stored_card']) === 1) {
                wc_add_notice(__('Kayıtlı kart ile 2D ödeme kapalıdır. Yeni kart ile 3D Secure ödeme kullanın.', 'halkode'), 'error');
                return ['result' => 'failure'];
            }

            $responseMethodRequestParameter = true;
            $environment_url = "FALSE" == $environment
                ? 'https://app.halkode.com.tr/ccpayment/api/paySmart3D'
                : 'https://staging.halkode.com.tr/ccpayment/api/paySmart3D';

            $payment_token_response = $this->getToken();
            $payment_token = is_object($payment_token_response) && !empty($payment_token_response->data->token)
                ? sanitize_text_field((string)$payment_token_response->data->token)
                : '';

            if ($payment_token === '') {
                wc_add_notice(__('HalkÖde ödeme tokenı güvenli şekilde alınamadı.', 'halkode'), 'error');
                return ['result' => 'failure'];
            }

            $price = 0;
            
            $dis_per_product_amount = 0;
            $dis_total_amount = 0;
            if ($order->get_discount_total() > 0) {
                $dis_total_amount = number_format($order->get_discount_total(), 2, ".", "");
                $item_count = count($order->get_items());
                $dis_per_product_amount = $dis_total_amount / $item_count;
            }

            $order_items = $order->get_items(array('line_item', 'fee', 'shipping'));
            foreach (WC()->cart->get_cart() as $cart_item) {
                $cart_product_id = $cart_item['product_id'];
                $is_recurring_cart = get_post_meta($cart_product_id, "_recurring", true);
            }

            foreach ($order_items as $item_id => $order_item) {


                $invoice['items'][] = [
                    'name' => $order_item->get_name(),

                    'price' => number_format($order_item->get_total(), 2, ".", "") / $order_item->get_quantity(),

                    'quantity' => $order_item->get_quantity(),

                    'description' => '',
                ];

                $price = $price + (number_format(($order_item->get_total() - $dis_per_product_amount), 2, ".", ""));
            }

            if ($order->get_total_tax() > 0) {
                $invoice['items'][] = [
                    'name' => 'Tax',

                    'price' => number_format($order->get_total_tax(), 2, ".", ""),

                    'quantity' => 1,

                    'description' => '',
                ];

                $price = $price + number_format($order->get_total_tax(), 2, ".", "");
            }

            $invoice['total'] = number_format($price, 2, ".", "");

            

            $invoice['bill_address1'] = isset($_POST['billing_address_1']) ? wc_clean(wp_unslash($_POST['billing_address_1'])) : '';

            $invoice['bill_address2'] = isset($_POST['billing_address_2']) ? wc_clean(wp_unslash($_POST['billing_address_2'])) : '';

            $invoice['bill_city'] = isset($_POST['billing_city']) ? wc_clean(wp_unslash($_POST['billing_city'])) : '';

            $invoice['bill_postcode'] = isset($_POST['billing_postcode']) ? wc_clean(wp_unslash($_POST['billing_postcode'])) : '';

            $invoice['bill_state'] = isset($_POST['billing_state']) ? wc_clean(wp_unslash($_POST['billing_state'])) : '';

            $invoice['bill_country'] = isset($_POST['billing_country']) ? wc_clean(wp_unslash($_POST['billing_country'])) : '';

            $invoice['bill_email'] = isset($_POST['billing_email']) ? wc_clean(wp_unslash($_POST['billing_email'])) : '';

            $invoice['bill_phone'] = isset($_POST['billing_phone']) ? wc_clean(wp_unslash($_POST['billing_phone'])) : '';


            $callback_url = add_query_arg(
                [
                    'halkode_3d_callback' => '1',
                    'wc_order_id' => $order_id,
                    'wc_order_key' => $order->get_order_key(),
                ],
                home_url('/')
            );
            $return_url = $callback_url;

            $stored_card = isset($_POST['stored_card']) ? absint($_POST['stored_card']) : 0;
            $expiry_month = absint($_POST['expiry_month'] ?? 0);
            $expiry_year = absint($_POST['expiry_year'] ?? 0);
            $card_number_clean = preg_replace('/\D+/', '', (string)($_POST['cc_number'] ?? ''));
            $cvv_clean = preg_replace('/\D+/', '', (string)($_POST['cc_cvv'] ?? ''));

            if (!$stored_card) {
                if (!preg_match('/^\d{12,19}$/', $card_number_clean)) {
                    wc_add_notice(__('Kart numarası formatı geçersiz.', 'halkode'), 'error');
                    return ['result' => 'failure'];
                }
                if (!preg_match('/^\d{3,4}$/', $cvv_clean)) {
                    wc_add_notice(__('CVV formatı geçersiz.', 'halkode'), 'error');
                    return ['result' => 'failure'];
                }
                if ($expiry_month < 1 || $expiry_month > 12 || $expiry_year < (int)date('Y') || $expiry_year > ((int)date('Y') + 20)) {
                    wc_add_notice(__('Kart son kullanma tarihi geçersiz.', 'halkode'), 'error');
                    return ['result' => 'failure'];
                }
            }

            $month = sprintf('%02d', $expiry_month);
            $year = (string)$expiry_year;

            $installment = max(1, absint($_POST['installments_number'] ?? 1));
            $payment_total = number_format((float) $order->get_total(), 2, '.', '');

            if ($installment > 1) {
                $raw_card_number = $card_number_clean;
                $card_bin = substr($raw_card_number, 0, 6);
                $token = $payment_token;

                if (strlen($card_bin) !== 6 || $token === '') {
                    wc_add_notice(__('Taksit doğrulaması için kart bilgisi veya ödeme tokenı eksik.', 'halkode'), 'error');
                    return ['result' => 'failure'];
                }

                $getpos_url = "FALSE" == $environment
                    ? 'https://app.halkode.com.tr/ccpayment/api/getpos'
                    : 'https://staging.halkode.com.tr/ccpayment/api/getpos';

                $getpos_headers = [
                    'Accept: application/json',
                    'Content-Type: application/json',
                    'Authorization: Bearer ' . $token,
                ];

                $getpos_request = [
                    'credit_card' => $card_bin,
                    'amount' => (float) $payment_total,
                    'currency_code' => $this->get_wc_currency(),
                    'merchant_key' => $this->get_option('merchant_key'),
                ];

                $getpos_response = getCurl(
                    $getpos_url,
                    'POST',
                    wp_json_encode($getpos_request),
                    $getpos_headers
                );

                $selected_option = null;
                if (
                    is_object($getpos_response)
                    && (int)($getpos_response->status_code ?? 0) === 100
                    && !empty($getpos_response->data)
                    && is_array($getpos_response->data)
                ) {
                    foreach ($getpos_response->data as $option) {
                        $option_installment = is_object($option)
                            ? (int)($option->installments_number ?? 0)
                            : (int)($option['installments_number'] ?? 0);

                        if ($option_installment === $installment) {
                            $selected_option = $option;
                            break;
                        }
                    }
                }

                if (!$selected_option) {
                    $getpos_message = is_object($getpos_response)
                        ? (string)($getpos_response->status_description ?? '')
                        : '';

                    wc_add_notice(
                        $getpos_message !== ''
                            ? sprintf(__('Seçilen taksit doğrulanamadı: %s', 'halkode'), $getpos_message)
                            : sprintf(__('Bu kart için %d taksit seçeneği doğrulanamadı.', 'halkode'), $installment),
                        'error'
                    );
                    return ['result' => 'failure'];
                }

                $selected_pos_id = is_object($selected_option)
                    ? (string)($selected_option->pos_id ?? '')
                    : (string)($selected_option['pos_id'] ?? '');

                $order->update_meta_data('_halkode_installments_number', $installment);
                $order->update_meta_data('_halkode_pos_id', $selected_pos_id);
                $order->update_meta_data('_halkode_card_bin', $card_bin);
                $order->save();
            } else {
                $order->update_meta_data('_halkode_installments_number', 1);
                $order->save();
            }

            try {
                $invoice_prefix = bin2hex(random_bytes(16));
            } catch (\Exception $e) {
                $invoice_prefix = str_replace('-', '', wp_generate_uuid4());
            }
            $invoice_id = $invoice_prefix . 'WOO' . $order_id;
            $order->update_meta_data('_halkode_invoice_id', $invoice_id);
            $order->update_meta_data('_halkode_expected_total', (float)$payment_total);
            $order->update_meta_data('_halkode_transaction_type', sanitize_text_field((string)$this->get_option('transaction_type')));
            $order->save();
            $order = $invoice_id;


            $pay_data = [
                'cc_holder_name' => sanitize_text_field(wp_unslash($_POST['cc_holder_name'] ?? '')),
                'cc_no' => $card_number_clean,
                'expiry_month' => $month,
                'expiry_year' => $year,
                'cvv' => $cvv_clean,
                'total' => (float)$payment_total,
                'installments_number' => $installment,
                'currency_code' => $this->get_wc_currency(),
                'merchant_key' => $this->get_option('merchant_key'),
                'invoice_id' => $order,
                'invoice_description' => $order_id . ' ödemesi',
                'hash_key' => $this->generateHashKey($payment_total, $installment, $this->get_wc_currency(), $this->get_option('merchant_key'), $order, $this->get_option('app_secret')),
                'name' => sanitize_text_field(wp_unslash($_POST['billing_first_name'] ?? '')),
                'surname' => sanitize_text_field(wp_unslash($_POST['billing_last_name'] ?? '')),
                'items' => $invoice['items'],
                'return_url' => $return_url,
                'cancel_url' => $callback_url,
                'transaction_type' => $this->get_option('transaction_type'),
                'payment_completed_by' => 'app',
            ];
            if ($is_recurring_cart == 'yes') {
                $pay_data['recurring_web_hook_key'] = $this->get_option('recurring_sale_webhook_key');
                $pay_data['order_type'] = "1";
                $pay_data['recurring_payment_number'] = get_post_meta($cart_product_id, 'payment_duration', true);
                $pay_data['recurring_payment_cycle'] = get_post_meta($cart_product_id, 'payment_cycle', true);
                $pay_data['recurring_payment_interval'] = get_post_meta($cart_product_id, 'payment_interval', true);
            }
            $request_body = wp_json_encode($pay_data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

            if (!is_string($request_body)) {
                wc_add_notice(__('Ödeme isteği oluşturulamadı.', 'halkode'), 'error');
                return ['result' => 'failure'];
            }

            $response = wp_remote_post($environment_url, [
                'timeout' => 45,
                'redirection' => 0,
                'sslverify' => true,
                'limit_response_size' => 1048576,
                'headers' => [
                    'Accept' => 'text/html,application/xhtml+xml,application/json',
                    'Content-Type' => 'application/json',
                    'Authorization' => 'Bearer ' . $payment_token,
                ],
                'body' => $request_body,
                'data_format' => 'body',
            ]);

            $card_number_clean = '';
            $cvv_clean = '';
            unset($pay_data['cc_no'], $pay_data['cvv']);

            if (is_wp_error($response)) {
                wc_add_notice(__('HalkÖde ödeme servisine güvenli bağlantı kurulamadı.', 'halkode'), 'error');
                return ['result' => 'failure'];
            }

            $http_code = (int)wp_remote_retrieve_response_code($response);
            $response_body = (string)wp_remote_retrieve_body($response);

            if ($http_code < 200 || $http_code >= 300 || $response_body === '') {
                wc_add_notice(__('HalkÖde 3D Secure isteği reddedildi.', 'halkode'), 'error');
                return ['result' => 'failure'];
            }

            $trimmed_response = ltrim($response_body);

            if (str_starts_with($trimmed_response, '{') || str_starts_with($trimmed_response, '[')) {
                $error_response = json_decode($response_body, true);
                $provider_message = is_array($error_response)
                    ? sanitize_text_field((string)($error_response['status_description'] ?? $error_response['message'] ?? ''))
                    : '';

                $order->add_order_note(
                    'HalkÖde paySmart3D başlatılamadı. ' .
                    ($provider_message !== '' ? $provider_message : 'Geçersiz API yanıtı.')
                );

                wc_add_notice(
                    $provider_message !== ''
                        ? $provider_message
                        : __('HalkÖde 3D Secure ödeme başlatılamadı.', 'halkode'),
                    'error'
                );
                return ['result' => 'failure'];
            }

            if (stripos($response_body, '<form') === false) {
                wc_add_notice(__('HalkÖde banka yönlendirme formu döndürmedi.', 'halkode'), 'error');
                return ['result' => 'failure'];
            }

            $handoff_token = halkode_save_handoff($order_id, [
                'type' => 'bank_html',
                'html' => $response_body,
            ]);

            if (is_wp_error($handoff_token)) {
                wc_add_notice($handoff_token->get_error_message(), 'error');
                return ['result' => 'failure'];
            }

            return [
                'result' => 'success',
                'redirect' => add_query_arg([
                    'order_id' => $order_id,
                    'halkode_handoff' => $handoff_token,
                ], home_url('/')),
            ];

        }

        function get_admin_installment()
        {

            $inst = [];

            $post = [
                'app_id' => $this->get_option('app_key'),

                'app_secret' => $this->get_option('app_secret'),
            ];


            $environment = $this->get_option('environment') == "yes" ? 'TRUE' : 'FALSE';

            
            $environment_url = "FALSE" == $environment ? 'https://app.halkode.com.tr/ccpayment/api/token' : 'https://staging.halkode.com.tr/ccpayment/api/token';


            if (!empty($this->get_option('app_key')) && !empty($this->get_option('app_secret')) && !empty($this->get_option('merchant_key')) && !empty($this->get_option('environment'))) {

                $token = getCurl($environment_url, 'POST', $post);

                if (empty($token) || !isset($token->data) || !isset($token->data->token)) {
                    return $inst;
                }

                $token = $token->data->token;
                $environment_url = "FALSE" == $environment ? 'https://app.halkode.com.tr/ccpayment/api/installments' : 'https://staging.halkode.com.tr/ccpayment/api/installments';
                $headers = ['Accept: application/json', 'Content-Type: application/json', "Authorization: Bearer $token"];
                $a['merchant_key'] = $this->get_option('merchant_key');

                $installments = getCurl($environment_url, 'POST', json_encode($a), $headers);

                $inst = [];

                if (empty($installments) || !isset($installments->installments) || !is_array($installments->installments)) {
                    return $inst;
                }

                foreach ($installments->installments as $key => $installment) {
                    $inst[$key + 1] = $installment;
                }


                return $inst;


            }

            return $inst;
        }

        public function generateHashKey($total, $installment, $currency_code, $merchant_key, $invoice_id,
                                        $app_secret)
        {

            $data = $total . '|' . $installment . '|' . $currency_code . '|' . $merchant_key . '|' . $invoice_id;

            try {
                $iv = bin2hex(random_bytes(8));
                $salt = bin2hex(random_bytes(2));
            } catch (\Exception $e) {
                return '';
            }
            $password = sha1($app_secret);

            $saltWithPassword = hash('sha256', $password . $salt);

            $encrypted = openssl_encrypt("$data", 'aes-256-cbc', "$saltWithPassword", null, $iv);

            $msg_encrypted_bundle = "$iv:$salt:$encrypted";
            $msg_encrypted_bundle = str_replace('/', '__', $msg_encrypted_bundle);

            return $msg_encrypted_bundle;
        }

        public function generateSaveCardCreateHashKey(
            $merchant_key,
            $customer_number,
            $card_number,
            $card_holder_name,
            $expiry_month,
            $expiry_year,
            $app_secret
        )
        {
            $data = $merchant_key . '|' . $customer_number . '|' . $card_holder_name . '|' . $card_number . '|' . $expiry_month . '|' . $expiry_year;
            try {
                $iv = bin2hex(random_bytes(8));
                $salt = bin2hex(random_bytes(2));
            } catch (\Exception $e) {
                return '';
            }
            $password = sha1($app_secret);
            $saltWithPassword = hash('sha256', $password . $salt);
            $encrypted = openssl_encrypt("$data", 'aes-256-cbc', "$saltWithPassword", null, $iv);
            $msg_encrypted_bundle = "$iv:$salt:$encrypted";
            $msg_encrypted_bundle = str_replace('/', '__', $msg_encrypted_bundle);

            return $msg_encrypted_bundle;

        }

        private function getToken()
        {

            $api_secret = $this->get_option('app_secret');
            $api_key = $this->get_option('app_key');
            $merchant_key = $this->get_option('merchant_key');
            $merchant_id = $this->get_option('merchant_id');
            $sandbox = $this->get_option('environment');


            $url = $sandbox == 'yes' ? 'https://staging.halkode.com.tr/ccpayment/api/token' : 'https://app.halkode.com.tr/ccpayment/api/token';

            $array = [
                'app_id' => $api_key,
                'app_secret' => $api_secret
            ];

            return $this->curl($url, 'POST', $array);

        }

        
        public function validate_fields()
        {
            $holder = sanitize_text_field(wp_unslash($_POST['cc_holder_name'] ?? ''));
            $number = preg_replace('/\D+/', '', (string)($_POST['cc_number'] ?? ''));
            $month = absint($_POST['expiry_month'] ?? 0);
            $year = absint($_POST['expiry_year'] ?? 0);
            $cvv = preg_replace('/\D+/', '', (string)($_POST['cc_cvv'] ?? ''));

            if ($holder === '') {
                wc_add_notice(__('Kart sahibi alanı zorunludur.', 'halkode'), 'error');
                return false;
            }

            if (!preg_match('/^\d{12,19}$/', $number)) {
                wc_add_notice(__('Kart numarası formatı geçersiz.', 'halkode'), 'error');
                return false;
            }

            if ($month < 1 || $month > 12) {
                wc_add_notice(__('Kart son kullanım ayı geçersiz.', 'halkode'), 'error');
                return false;
            }

            if ($year < (int)date('Y') || $year > ((int)date('Y') + 20)) {
                wc_add_notice(__('Kart son kullanım yılı geçersiz.', 'halkode'), 'error');
                return false;
            }

            if (!preg_match('/^\d{3,4}$/', $cvv)) {
                wc_add_notice(__('CVV formatı geçersiz.', 'halkode'), 'error');
                return false;
            }

            return true;
        }

        public function is_available()
        {
            if (!parent::is_available()) {
                return false;
            }

            $is_live = $this->get_option('environment') === 'no';

            
            
            if ($is_live && !halkode_is_local_host() && !is_ssl()) {
                return false;
            }

            return true;
        }

        public function do_ssl_check()
        {
            if ($this->enabled !== 'yes') {
                return;
            }

            $is_live = $this->get_option('environment') === 'no';

            
            if (halkode_is_local_host()) {
                return;
            }

            if ($is_live && !is_ssl()) {
                echo '<div class="notice notice-error"><p><strong>Halk Ödeme:</strong> Canlı / Production gerçek alan adında HTTPS gerektirir.</p></div>';
                return;
            }

            if (!is_ssl()) {
                echo '<div class="notice notice-warning"><p><strong>Halk Ödeme:</strong> Staging HTTP üzerinde çalışıyor. Canlıya geçmeden önce gerçek alan adında HTTPS kullanın.</p></div>';
            }
        }

        public function get_wc_currency()
        {
            if (function_exists('get_woocommerce_currency')) {
                return get_woocommerce_currency();
            }

            return get_option('woocommerce_currency');
        }
    }
