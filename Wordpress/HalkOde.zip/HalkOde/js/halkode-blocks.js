
(function () {
    'use strict';
    if (!window.wc || !window.wc.wcBlocksRegistry || !window.wc.wcSettings || !window.wp || !window.wp.element) return;

    var el = window.wp.element.createElement;
    var useState = window.wp.element.useState;
    var useEffect = window.wp.element.useEffect;
    var decodeEntities = window.wp.htmlEntities ? window.wp.htmlEntities.decodeEntities : function (v) { return v; };
    var registerPaymentMethod = window.wc.wcBlocksRegistry.registerPaymentMethod;
    var settings = window.wc.wcSettings.getSetting('halkode_sanalpos_data', {});

    function Field(props) {
        return el('p', { className: 'form-row ' + (props.className || 'form-row-wide') + ' halkode-field-group' },
            el('label', null, props.label, el('span', { className: 'required' }, ' *')),
            el('input', {
                type: props.type || 'text',
                value: props.value,
                maxLength: props.maxLength,
                inputMode: props.inputMode,
                autoComplete: props.autoComplete || 'off',
                placeholder: props.placeholder || '',
                onChange: function (e) { props.onChange(e.target.value); },
                className: 'input-text'
            })
        );
    }

    function SelectField(props) {
        return el('p', { className: 'form-row ' + (props.className || 'form-row-wide') + ' halkode-field-group' },
            el('label', null, props.label, el('span', { className: 'required' }, ' *')),
            el('select', {
                value: props.value,
                onChange: function (e) { props.onChange(e.target.value); },
                className: 'input-text'
            },
                el('option', { value: '' }, props.placeholder || 'Seçiniz'),
                props.options.map(function (opt) {
                    return el('option', { key: opt.value, value: opt.value }, opt.label);
                })
            )
        );
    }

    function formatCard(value) {
        return (value || '').replace(/\D/g, '').substring(0, 16);
    }

    function InstallmentOption(props) {
        var opt = props.opt || {};
        var selected = props.selected;
        var onSelect = props.onSelect;
        return el('div', {
                className: 'halkode-block-installment-option ' + (String(selected || '') === String(opt.installments_number || '') ? 'active' : ''),
                onClick: function () { if (onSelect) onSelect(opt); }
            },
            el('div', { className: 'halkode_heading' }, opt.label || 'Taksit'),
            el('div', { className: 'halkode_amount' }, (opt.amount || '0.00') + ' ' + (opt.currency_code || 'TRY')),
            el('div', { className: 'halkode_installment_number' }, (opt.installments_number || '1') + ' X'),
            el('div', { className: 'halkode_total_amount' }, (opt.per_installment || opt.amount || '0.00') + ' ' + (opt.currency_code || 'TRY'))
        );
    }

    function Content(props) {
        var _a = useState(''), holder = _a[0], setHolder = _a[1];
        var _b = useState(''), number = _b[0], setNumber = _b[1];
        var _c = useState(''), expiryMonth = _c[0], setExpiryMonth = _c[1];
        var _d = useState(''), expiryYear = _d[0], setExpiryYear = _d[1];
        var _e = useState(''), cvv = _e[0], setCvv = _e[1];
        var _f = useState([]), options = _f[0], setOptions = _f[1];
        var _g = useState(null), selectedOption = _g[0], setSelectedOption = _g[1];
        var _h = useState(false), loading = _h[0], setLoading = _h[1];
        var _i = useState(''), lastBin = _i[0], setLastBin = _i[1];
        var onPaymentSetup = props.eventRegistration.onPaymentSetup || props.eventRegistration.onPaymentProcessing;
        var responseTypes = props.emitResponse.responseTypes;
        var use3d = true;

        useEffect(function () {
            var cleanNumber = (number || '').replace(/\D/g, '');
            var currentBin = cleanNumber.substring(0, 6);
            if (cleanNumber.length < 6) {
                setOptions([]);
                setSelectedOption(null);
                setLastBin('');
                return;
            }
            if (!settings.ajaxUrl || currentBin === lastBin) {
                return;
            }
            setLastBin(currentBin);
            setLoading(true);
            var body = new URLSearchParams();
            body.set('action', 'get_installment');
            body.set('cc_number', currentBin);
            body.set('nonce', settings.installmentNonce || '');
            fetch(settings.ajaxUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                body: body.toString(),
                credentials: 'same-origin'
            }).then(function (res) {
                return res.json();
            }).then(function (data) {
                var parsed = Array.isArray(data && data.options) ? data.options : [];
                if (!parsed.length) {
                    setOptions([]);
                    setSelectedOption(null);
                    return;
                }
                parsed = parsed.map(function (opt, index) {
                    return {
                        pos_id: String(opt.pos_id || ''),
                        amount: String(opt.amount || '0.00'),
                        currency_code: String(opt.currency_code || 'TRY'),
                        installments_number: String(opt.installments_number || (index + 1)),
                        label: String(opt.label || ((opt.installments_number || (index + 1)) + ' Taksit')),
                        per_installment: String(opt.per_installment || opt.amount || '0.00')
                    };
                });
                setOptions(parsed);
                setSelectedOption(parsed[0]);
            }).catch(function () {
                setOptions([]);
                setSelectedOption(null);
            }).finally(function () {
                setLoading(false);
            });
        }, [number, lastBin]);

        useEffect(function () {
            if (!onPaymentSetup) return function () {};
            var unsubscribe = onPaymentSetup(function () {
                var cleanNumber = number.replace(/\D/g, '');
                if (!holder.trim() || cleanNumber.length < 12 || !expiryMonth || !expiryYear || cvv.replace(/\D/g, '').length < 3) {
                    return { type: responseTypes.ERROR, message: 'Lütfen kart bilgilerini eksiksiz ve doğru girin.' };
                }
                var month = expiryMonth;
                var year = expiryYear;
                var chosen = selectedOption || {};
                var data = {
                    cc_holder_name: holder.trim(),
                    cc_number: cleanNumber,
                    cc_cvv: cvv.replace(/\D/g, ''),
                    expiry_month: month,
                    expiry_year: year,
                    'halkode_sanalpos-card-expiry': month + ' / ' + year,
                    halkode_3d: '1',
                    stored_card: '0',
                    installments_number: chosen.installments_number || '1'
                };
                data.pay_via_3d = 'yes';
                return { type: responseTypes.SUCCESS, meta: { paymentMethodData: data } };
            });
            return unsubscribe;
        }, [holder, number, expiryMonth, expiryYear, cvv, selectedOption, onPaymentSetup, responseTypes.ERROR, responseTypes.SUCCESS]);

        return el('div', { className: 'halkode-block-payment-form' },
            el('div', { className: 'halkode-block-header' },
                el('div', null,
                    el('div', { className: 'halkode-block-title' }, decodeEntities(settings.title || 'Halk Ödeme Hizmetleri Pos')),
                    el('div', { className: 'halkode-block-subtitle' }, settings.description ? decodeEntities(settings.description) : 'Kart numaranızın ilk 6 hanesi girildiğinde taksit seçenekleri /api/getpos üzerinden otomatik sorgulanır.')
                ),
                settings.logoUrl ? el('div', { className: 'halkode-block-logo-wrap' }, el('img', { src: settings.logoUrl, alt: 'Halk Öde', className: 'halkode-block-logo' })) : null
            ),
            el('div', { className: 'halkode-field-grid' },
                Field({ label: 'Kart Üzerindeki İsim', value: holder, onChange: setHolder, autoComplete: 'cc-name', placeholder: 'Ad Soyad' }),
                Field({ label: 'Kart Numarası', value: number, onChange: function (v) { setNumber(formatCard(v)); }, inputMode: 'numeric', maxLength: 16, autoComplete: 'cc-number', placeholder: '0000000000000000' }),
                el('div', { className: 'halkode-field-row' },
                    el('div', { className: 'halkode-expiry-block' },
                        el('div', { className: 'halkode-expiry-label' }, 'Son Kullanma Tarihi (AA / YYYY)', el('span', { className: 'required' }, ' *')),
                        el('div', { className: 'halkode-expiry-selects' },
                            SelectField({
                                label: 'Ay',
                                value: expiryMonth,
                                onChange: setExpiryMonth,
                                placeholder: 'AA',
                                className: 'halkode-expiry-select-field',
                                options: Array.from({ length: 12 }, function (_, i) {
                                    var v = String(i + 1).padStart(2, '0');
                                    return { value: v, label: v };
                                })
                            }),
                            SelectField({
                                label: 'Yıl',
                                value: expiryYear,
                                onChange: setExpiryYear,
                                placeholder: 'YYYY',
                                className: 'halkode-expiry-select-field',
                                options: Array.from({ length: 11 }, function (_, i) {
                                    var y = String(new Date().getFullYear() + i);
                                    return { value: y, label: y };
                                })
                            })
                        )
                    ),
                    Field({ label: 'CVV', value: cvv, onChange: setCvv, type: 'password', inputMode: 'numeric', maxLength: 4, autoComplete: 'cc-csc', placeholder: 'CVV', className: 'form-row-wide halkode-cvv-wrap' })
                )
            ),
            el('div', { className: 'halkode-block-installment-box ' + (options.length ? '' : 'is-hidden') },
                el('div', { className: 'halkode-installment-head' },
                    el('strong', null, 'Taksit Seçenekleri'),
                    el('span', null, loading ? 'Taksit seçenekleri /api/getpos üzerinden yükleniyor...' : 'Kartınıza uygun taksit seçeneğini seçin.')
                ),
                el('div', { className: 'halkode-block-installments' }, options.map(function (opt) {
                    return el(InstallmentOption, { key: opt.installments_number + '-' + opt.pos_id, opt: opt, selected: selectedOption ? selectedOption.installments_number : '', onSelect: setSelectedOption });
                }))
            ),
            use3d ? el('label', { className: 'halkode-3d-toggle' },
                el('input', { type: 'checkbox', checked: true, disabled: true }),
                ' 3D Secure ile güvenli ödeme'
            ) : null
        );
    }

    var Label = function (props) {
        return el(props.components.PaymentMethodLabel, { text: decodeEntities(settings.title || 'Halk Ödeme Hizmetleri Pos') });
    };

    registerPaymentMethod({
        name: 'halkode_sanalpos',
        label: el(Label, null),
        content: el(Content, null),
        edit: el(Content, null),
        canMakePayment: function () { return true; },
        ariaLabel: decodeEntities(settings.title || 'Halk Ödeme Hizmetleri Pos'),
        supports: { features: settings.supports || ['products'] }
    });
})();
