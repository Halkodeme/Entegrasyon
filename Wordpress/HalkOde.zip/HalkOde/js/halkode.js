
jQuery(document).ready(function(){

   var lastBin = '';

   function resetInstallments() {
       jQuery('#installments').html('');
       jQuery('.installments_number').val('1');
       jQuery('#halkode-installment-box').addClass('is-hidden');
   }

   function normalizeCard(value) {
       return (value || '').replace(/\D/g, '').substring(0,16);
   }

   function formatCard(value) {
       return normalizeCard(value);
   }

   jQuery(document).on('input paste cut blur', '#cc_number', function () {
       var formatted = formatCard(jQuery(this).val());
       jQuery(this).val(formatted);

       var raw = normalizeCard(formatted);
       var currentBin = raw.substring(0,6);

       if (raw.length < 6) {
           lastBin = '';
           resetInstallments();
           return;
       }

       if (currentBin !== lastBin) {
           resetInstallments();
           lastBin = currentBin;
       }

       if (jQuery('#installments').html() === '') {
           var formData = 'cc_number=' + encodeURIComponent(raw.substring(0, 6));
           ajaxRequest(woocommerce_params.ajax_url, formData);
       }
   });

   jQuery(document).on('dblclick', '#cc_number', function () {
       jQuery(this).val('');
       lastBin = '';
       resetInstallments();
   });

   jQuery(document).on('click', '#recurring_checkbox', function(){
       if(jQuery(this).is(':checked'))
            jQuery('.recurring_option_fields').show();
       else
            jQuery('.recurring_option_fields').hide();
   });

});

function ajaxRequest(url,formData) {
    var spinner = '<img src="'+halkode_var.spinner+'" class="halkode_spinner"/>';
    jQuery('.halkode_spinner_blk').html(spinner);

    jQuery.ajax({
        url: url+'?action=get_installment',
        type: 'post',
        data: formData+'&nonce='+encodeURIComponent(halkode_var.installmentNonce),
        dataType: 'JSON',
        success: function (data) {
            jQuery('#installments').html(data.data || '');
            jQuery('.installments_number').val(data.installments_number || '1');
            if (data.data) {
                jQuery('#halkode-installment-box').removeClass('is-hidden');
            } else {
                jQuery('#halkode-installment-box').addClass('is-hidden');
            }
            jQuery('.halkode_spinner').remove();
        },
        error: function (jqXhr, textStatus, errorThrown) {
            jQuery('.halkode_spinner').remove();
            jQuery('#halkode-installment-box').addClass('is-hidden');
        }
    });
}
